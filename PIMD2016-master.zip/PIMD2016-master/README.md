# PIMD2016
paper ACML'16 [Proper Inner Product with Mean Displacement for Gaussian Noise Invariant ICA]
